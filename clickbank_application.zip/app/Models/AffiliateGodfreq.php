<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateGodfreq extends Model
{
    protected $table = 'affiliate_godfreq';
}
