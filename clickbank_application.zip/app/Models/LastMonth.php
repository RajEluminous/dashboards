<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LastMonth extends Model
{
    protected $table = 'last_month';
}
