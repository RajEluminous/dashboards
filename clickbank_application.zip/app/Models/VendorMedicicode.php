<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorMedicicode extends Model
{
    protected $table = 'vendor_medicicode';
}
