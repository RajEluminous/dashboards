<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AweberAccounts extends Model
{
    protected $table = 'aweber_accounts';
}
