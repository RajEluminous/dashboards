<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IncomingTrafficStatus extends Model
{
    protected $table = 'sra_incoming_traffic_status';
}
