<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorType2free extends Model
{
    protected $table = 'vendor_type2free';
}
