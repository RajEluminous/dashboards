<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kendago extends Model
{
    protected $table = 'kendago';
}
