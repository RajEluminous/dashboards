<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorSleepwaves extends Model
{
    protected $table = 'vendor_sleepwaves';
}
