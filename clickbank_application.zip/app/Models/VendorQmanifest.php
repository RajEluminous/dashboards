<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorQmanifest extends Model
{
    protected $table = 'vendor_qmanifest';
}
