<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopAffiliate extends Model
{
    protected $table = 'top_affiliate';
}
