<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor15Manifest extends Model
{
    protected $table = 'vendor_15manifest';
}
