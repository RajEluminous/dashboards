<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateQmanifest extends Model
{
    protected $table = 'affiliate_qmanifest';
}
