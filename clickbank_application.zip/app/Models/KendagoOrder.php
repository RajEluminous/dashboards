<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KendagoOrder extends Model
{
    protected $table = 'kendago_order';
}
