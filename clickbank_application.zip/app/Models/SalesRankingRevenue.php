<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SalesRankingRevenue extends Model
{
    protected $table = 'sales_ranking_revenue';
}
