<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorMetabolicb extends Model
{
    protected $table = 'vendor_metabolicb';
}
