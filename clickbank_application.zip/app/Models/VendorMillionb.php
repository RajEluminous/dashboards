<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorMillionb extends Model
{
    protected $table = 'vendor_millionb';
}
