<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SalesByARS extends Model
{
    protected $table = 'sales_by_ars';
}
