<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Affiliate15Happy extends Model
{
    protected $table = 'affiliate_15happy';
}
