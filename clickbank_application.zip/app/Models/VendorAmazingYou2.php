<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorAmazingYou2 extends Model
{
    protected $table = 'vendor_amazingyou2';
}
