<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorMtimewarp extends Model
{
    protected $table = 'vendor_mtimewarp';
}
