<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateUpmagnet extends Model
{
    protected $table = 'affiliate_upmagnet';
}
