<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorGodfreq extends Model
{
    protected $table = 'vendor_godfreq';
}
