<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorPnmanifest extends Model
{
    protected $table = 'vendor_pnmanifest';
}
