<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateMtimewarp extends Model
{
    protected $table = 'affiliate_mtimewarp';
}
