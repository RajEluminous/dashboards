<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Affiliate15Manifest extends Model
{
    protected $table = 'affiliate_15manifest';
}
