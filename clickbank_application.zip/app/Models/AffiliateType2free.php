<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateType2free extends Model
{
    protected $table = 'affiliate_type2free';
}
