<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VendorTopAffiliate extends Model
{
    protected $table = 'vendor_top_affiliate';
}
