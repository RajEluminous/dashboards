<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateRevenue extends Model
{
    protected $table = 'affiliate_revenue';
}
