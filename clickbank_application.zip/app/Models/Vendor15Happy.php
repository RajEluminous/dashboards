<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor15Happy extends Model
{
    protected $table = 'vendor_15happy';
}
