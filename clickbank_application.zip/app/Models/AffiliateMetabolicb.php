<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateMetabolicb extends Model
{
    protected $table = 'affiliate_metabolicb';
}
