<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AffiliateMillionb extends Model
{
    protected $table = 'affiliate_millionb';
}
