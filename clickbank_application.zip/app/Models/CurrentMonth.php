<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CurrentMonth extends Model
{
    protected $table = 'current_month';
}
