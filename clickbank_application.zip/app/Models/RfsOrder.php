<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RfsOrder extends Model
{
    protected $table = 'rfs_order';
}
