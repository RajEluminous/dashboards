<footer>
  <div class="pull-right">
    Limitless Factor Pte Ltd</a>
  </div>
  <div class="clearfix"></div>
</footer>