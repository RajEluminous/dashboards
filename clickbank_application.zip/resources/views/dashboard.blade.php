@extends('layouts.new_app')

@section('content')
    <div class="right_col" role="main">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Dashboards</div>

                    <div class="card-body">
                        Welcome to the statistic boards.
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
